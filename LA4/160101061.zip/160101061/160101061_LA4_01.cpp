#include <bits/stdc++.h>
using namespace std;

void PrinT(int H[],int n){

	for (int i = 0; i < n; ++i)
	{
		cout << H[i];

		if (i!=n-1)
			cout << " ";
	}
	printf("\n\n");

}

void min_heapify(int H[],int n,int i){

	int large=i;
	int l=(3*i)+1;
	int m=(3*i)+2;
	int r=(3*i)+3;

	if (l<n && H[large] > H[l])
		large=l;

	if (m<n && H[large] > H[m])
		large=m;

	if (r<n && H[large] > H[r])
		large=r;

	if (large!=i)
	{
		swap(H[i],H[large]);
		min_heapify(H,n,large);
	}

	return;
}

void InserT(int H[],int &n,int k){

	if (n > 100)
	{
		//printf("Heap size is full\n\n");
		return;
	}

	H[n]=k;
	n++;

	int s=n-1;
	int p=(s-1)/3;

	while(s>0 && H[p] > H[s]){
		swap(H[s],H[p]);
		s=p;
		p=(p-1)/3;
	}

	cout << k << " is inserted" <<endl << endl;
	PrinT(H,n);

	return;
}

void DeletE(int H[],int &n){

	if (n==0)
	{
		printf("Empty Heap!\n");
		return;
	}

	cout << H[0] << " is deleted" <<endl << endl;

	H[0]=H[--n];

	min_heapify(H,n,0);

	PrinT(H,n);

	return;
}

int main(){

	int n,H[100],k;
	cin >> n;

	for (int i = 0; i < n; ++i)
		cin >> H[i]; 

	k=(n-2)/3;

	for (int i = k; i >= 0 ; --i)
		min_heapify(H,n,i);

	PrinT(H,n);

	char c;

	while(1){
		cin >> c;

		if (c=='I' || c=='i')
		{
			cin >> k;
			InserT(H,n,k);
		}

		else if (c=='D' || c=='d')
		{
			DeletE(H,n);
		}
		else
			break;
		
	}

	return 0;
}