#include <bits/stdc++.h>
using namespace std;

struct node
{
	int key;
	node *right;
	node *left;
	node *parent;
};

node *create(int k){

	node *temp=new node;

	temp->key=k;
	temp->right=NULL;
	temp->left=NULL;
	temp->parent=NULL;

	return temp;

}

void BST_INSERT(node * &root,int k){

	node *temp=create(k);

	if (root==NULL)
	{
		root=temp;
		cout << k << " is inserted" <<endl;
		return;
	}

	node *p,*temp1=root;

	while(temp1!=NULL){

		p=temp1;

		if (temp1->key >= k)
			temp1=temp1->left;

		else
			temp1=temp1->right;
	}

	temp->parent=p;

	if (p->key >= k)
		p->left=temp;	
	
	else
		p->right=temp;

	cout << k << " is inserted" <<endl;
	
	return ;
}

node *BST_SEARCH(node *root,int k){

	if (root==NULL || root->key == k)
	{
		return root;
	}

	if (root->key >= k)
	{
		return BST_SEARCH(root->left,k);
	}
	else{
		return BST_SEARCH(root->right,k);
	}
}

node *minn(node *n){

	while(n->left!=NULL)
		n=n->left;
	
	return n;
}

node *successor(node *root,int k){

	node *h=BST_SEARCH(root,k);

	if (h->right!=NULL)
		return minn(h->right);
	
	else{

		node *y=h->parent;

		while(y!=NULL && h==y->right){

			h=y;
			y=y->parent;
		}

		return y;
	}
}

void BST_DELETE(node * &root,int k){

	node *temp=BST_SEARCH(root,k);

	if (temp==NULL)
	{
		cout << k << " cannot be deleted" << endl;
		return;
	}

	node *p;

	if (temp->right==NULL || temp->left==NULL)
		p=temp;	
	
	else
		p=successor(root,temp->key);
	
	node *x=NULL;

	if (p->left==NULL)
		x=p->right;
	
	else
		x=p->left;

	if (x != NULL)
		x->parent = p->parent;

	if (p->parent == NULL)
		root = x;

	else if (p == p->parent->left)
		p->parent->left = x;
	
	else
		p->parent->right = x;
	
	if (p != temp)
		temp->key = p->key;
	
	free(p);

	cout << k << " is deleted" << endl;

	return;
}

void INORDER(node *root){

	if (root==NULL)
		return;

	INORDER(root->left);

	cout << root->key << " " ;

	INORDER(root->right);

	return;
}


int main(){


	string s;
	int N;
	node *root=NULL;

	while(1){

		cin >> s;

		if (s=="-1")
		{
			INORDER(root);
			cout << endl;
			break;
		}

		cin >> N;

		if (s=="INSERT" || s=="i")
			BST_INSERT(root,N);
		
		else if (s=="SEARCH" || s=="s")
		{
			if (BST_SEARCH(root,N)!=NULL)
				cout << N << " is found" << endl;
			
			else
				cout << N << " is not found" << endl;
		}

		else if (s=="DELETE" || s=="d")
			BST_DELETE(root,N);
		
		else
			cout << "Wrong Input" << endl;
	}

	return 0;
}