#include <bits/stdc++.h>
using namespace std;

struct node						// structure
{
	int data;
	int row;
	int coloum;
	int colour;
	int max_parent;
	node *parent;
	node *next;
};
	
node *create(int k,int i,int j){				// create node

	node *temp=new node;
	temp->data=k;
	temp->row=i;
	temp->coloum=j;
	temp->max_parent=1;
	temp->colour=0;
	temp->parent=NULL;
	temp->next=NULL;
}

void add(node *a,int d,int k,int l){			// add node after node a

	node *temp=create(d,k,l);
	node *t=a;

	if (a->next==NULL)
	{
		a->next=temp;
		temp->next=NULL;
		return;
	}

	while(t->next!=NULL)
		t=t->next;
	
	t->next=temp;
	temp->next=NULL;

	return;
}

void adj_list(node *datas[][6],int i,int j,int N){			// create adj. list

	int p=2;

	if (j%2==0)
		p=datas[i][j+1]->data;
	else
		p=datas[i][j-1]->data;

	for (int k = i+1 ; k < N ; ++k)
	{
		for (int l = 0; l < 6; ++l)
		{
			if (p==datas[k][l]->data)
				add(datas[i][j],p,k,l);
		}
	}

	return;
}

void dfs_visit(node *datas[][6],int i,int j){

	node *extra=NULL,*head=datas[i][j]->next;
	int max1=0;


	while(head!=NULL){

		if (datas[head->row][head->coloum]->colour==0)
		{
			dfs_visit(datas,head->row,head->coloum);
		}

		if (max1 < datas[head->row][head->coloum]->max_parent){
			max1=datas[head->row][head->coloum]->max_parent;
			extra=head;
		}
		head=head->next;

	}

	if (extra!=NULL)
	{
		datas[i][j]->parent=datas[extra->row][extra->coloum];
	}

	datas[i][j]->max_parent=max1+1;

	datas[i][j]->colour=1;

	return;
}

void dfs(node *datas[][6],int N){

	for (int i = 0; i < N ; ++i)
	{
		for (int j = 0; j < 6; ++j)
		{
			if (datas[i][j]->colour==0)
				dfs_visit(datas,i,j);			
		}
	}

	return;
}

void print(int s,int max,node *datas[][6],int i1,int j1){

	cout << "Case #" <<s  << endl;
	cout << max <<endl;

	node *temp=datas[i1][j1];

	while(temp!=NULL){					// print all data

		cout << temp->row+1;

	switch(temp->coloum){

		case 0 :cout << " front";break;
		case 1 :cout << " back";break;
		case 2 :cout << " left";break;
		case 3 :cout << " right";break;
		case 4 :cout << " top";break;
		case 5 :cout << " bottom";break;
	}

	cout <<endl;

		temp=temp->parent;
	}

	cout << endl;

	return;
}

void function1(int N,int s){

	node *datas[N][6];
	int p,max=0;

	for (int i = 0; i < N; ++i)					
	{
		for (int j = 0; j < 6 ; ++j)
		{
			cin >> p;
			datas[i][j]=create(p,i,j);
		}
	}

	for (int i = N-1; i >=0 ; --i)
	{										
		for (int j = 0; j < 6; ++j)
		{
			adj_list(datas,i,j,N);					
		}		
	}


	dfs(datas,N);

	int i1,j1;

	for (int i = 0; i < N; ++i)
	{
		for (int j = 0; j < 6; ++j)
		{
			if (max < datas[i][j]->max_parent ){
				i1=i;
				j1=j;
				max=datas[i][j]->max_parent;
			}
		}
	}

	print(s,max,datas,i1,j1);

	
	return;
}

int main()
{
	int N,s=1;

	while(1){

		cin >> N;

		if (N==0)
			break;

		function1(N,s);
		s++;
	}
	
	return 0;
}
/*

3
1 2 2 2 1 2
3 3 3 3 3 3
3 2 1 1 1 1
10
1 5 10 3 6 5
2 6 7 3 6 9
5 7 3 2 1 9
1 3 3 5 8 10
6 6 2 2 4 4
1 2 3 4 5 6
10 9 8 7 6 5
6 1 2 3 4 7
1 2 3 3 2 1
3 2 1 1 2 3
0

*/