#include <bits/stdc++.h>
using namespace std;

struct node 				// structure
{
	int data;
	int colour;
	int parent;
	node *next;	
};

node *create(int k){		// create node

	node *temp=new node;
	temp->data=k;
	temp->colour=0;
	temp->next=NULL;
	return temp;
}

void add(node *a,int k){		// add a node in linked list of head node a

	node *temp=create(k);
	node *t=a;

	if (a->next==NULL)
	{
		a->next=temp;
		temp->next=NULL;
		return;
	}

	while(t->next!=NULL)
		t=t->next;
	
	t->next=temp;
	temp->next=NULL;	

	return;
}

void add_8(node *head,int i){		// add 8 possible node after each switch

	int i1,i2,i3,i4,ii=i;

	i1=i/1000;
	i=i%1000;

	i2=i/100;
	i=i%100;

	i3=i/10;
	i=i%10;

	i4=i;

	int k,k1;

	if (i4==0)
		k1=9;
	else
		k1=i4-1;

	k=(k1)+(i3*10)+(i2*100)+(i1*1000);
	add(head,k);

	if (i4==9)
		k1=0;
	else
		k1=i4+1;

	k=k1+(i3*10)+(i2*100)+(i1*1000);
	add(head,k);

	if (i3==9)
		k1=0;
	else
		k1=i3+1;

	k=i4+(k1*10)+(i2*100)+(i1*1000);
	add(head,k);

	if (i3==0)
		k1=9;
	else
		k1=i3-1;

	k=i4+(k1*10)+(i2*100)+(i1*1000);
	add(head,k);

	if (i2==9)
		k1=0;
	else
		k1=i2+1;

	k=i4+(i3*10)+(k1*100)+(i1*1000);
	add(head,k);

	if (i2==0)
		k1=9;
	else
		k1=i2-1;

	k=i4+(i3*10)+(k1*100)+(i1*1000);
	add(head,k);

	if (i1==9)
		k1=0;
	else
		k1=i1+1;

	k=i4+(i3*10)+(i2*100)+(k1*1000);
	add(head,k);

	if (i1==0)
		k1=9;
	else
		k1=i1-1;

	k=i4+(i3*10)+(i2*100)+(k1*1000);
	add(head,k);

	return;
}

void call_main_function(int a,int b){			// call function

	int N=10000;

	node *head[N],*temp;

	for (int i = 0; i < N; ++i)
	{
		head[i]=create(i);
		add_8(head[i],i);
	}

	int k,k1,k2,k3,k4;
	cin >> k;	

	for (int i = 0; i < k; ++i)					// colour black of forbidden digits
	{
		cin >> k1 >> k2 >> k3 >> k4;
		k4=k4+(k3*10)+(k2*100)+(k1*1000);

		head[k4]->colour=2;
	}

	int out=-1,in=-1,queue[10000],d[10000]={0},w;

	queue[++in]=a;
	head[a]->colour=1;

	while(in!=out){					// normal bfs

		w=queue[++out];

		if (w==b)									// if no. is matched with target print its distance
		{
			cout << d[w] << endl;
			return;
		}

		temp=head[w]->next;

		while(temp!=NULL){

			if (head[temp->data]->colour==0)
			{
				queue[++in]=temp->data;
				head[temp->data]->colour=1;
				d[temp->data]=d[w]+1;
			}

			temp=temp->next;
		}

		head[w]->colour=2;
	}

	cout << "-1" << endl;					// if not possible to get target print -1
	return;

}

int main(){

	int n;
	cin >> n;

	int a1,a2,a3,a4,a,b;

	for (int i = 0; i < n; ++i)
	{										// form 2 no. from digits
		cin >> a1 >> a2 >> a3 >> a4;
		a=a4+(a3*10)+(a2*100)+(a1*1000);

		cin >> a1 >> a2 >> a3 >> a4;
		b=a4+(a3*10)+(a2*100)+(a1*1000);

		call_main_function(a,b);
	}

	return 0;
}
