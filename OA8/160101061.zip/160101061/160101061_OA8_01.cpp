#include <bits/stdc++.h>
using namespace std;

struct node				//structure
{
	int data;
	int colour;
	int parent;
	node *next;
};

node *create(int k){			// create a node with data k

	node *temp=new node;
	temp->data=k;
	temp->colour=0;
	temp->parent=0;
	temp->next=NULL;
	return temp;
}

void add(node *a,int k){			// add a node of data k in end of node a

	node *temp=create(k);
	node *t=a;

	if (a->next==NULL)
	{
		a->next=temp;
		temp->next=NULL;
		return;
	}

	while(t->next!=NULL)
		t=t->next;
	
	t->next=temp;
	temp->next=NULL;	

	return;
}

void call(node *Head[],node *a,node*b){		// print a list from node a to node b

	if (a->data==b->data)
	{
		cout << a->data << " ";

		return;
	}

	if (b->parent==0)
	{
		cout << b->data <<" " ;
		return;
	}

	call(Head,a,Head[b->parent]);

	cout << b->data << " ";

	return;
}

void print_path(node *Head[],int cycles[][2],int i)			// print a cycle
{
	call(Head,Head[cycles[i][0]],Head[cycles[i][1]]);

	cout << cycles[i][0];

	return;
}

void DFS_VISIT(node *Head[],node *a,int &CyC,int cycles[][2],node *Connect[],int &CnC){		// Dfs visit
    
    node *temp=Head[a->data]->next;  
    Head[a->data]->colour=1;			// visited node become grey
    add(Connect[CnC],a->data);			// add in Connect list
    
    while(temp!=NULL){					// all adjcent nodes of node a
        
        if(Head[temp->data]->colour==0){			// if node is white

        	Head[temp->data]->parent=a->data;
            DFS_VISIT(Head,temp,CyC,cycles,Connect,CnC);
        }

        else if (a->data!=Head[temp->data]->parent && temp->data!=Head[a->data]->parent && Head[temp->data]->colour==2){			// if next node is not parent and next node is black that means it make a new cycle from node a to node temp

    		CyC++;
    		cycles[CyC][0] = a->data;
    		cycles[CyC][1] = temp->data;
    	}

        temp=temp->next;
    }
    
    Head[a->data]->colour=2;			// node become black
    
    return ;
}

int main() {
	
	int N,E;
	cin >> N>>E;
	
	node *Head[N+1];
	
	for(int i=1; i <= N ; ++i){			// assign all node as head 

	    Head[i]=create(i);
	}
	
	int n1,n2;
	
	for(int i=1; i <= E ; ++i){			// make adj node list
	    
	    cin >> n1 >> n2;

	    add(Head[n1],n2);
	    add(Head[n2],n1);
	}

	node *temp;

	node *Connect[N+1];

	int CnC=0,CyC=0,cycles[N*N][2];
	
	for(int i=1; i <= N ; ++i){				// Main Dfs
	    
	    if(Head[i]->colour==0){

	        CnC++;
	        Connect[CnC]=create(CnC);

	        DFS_VISIT(Head,Head[i],CyC,cycles,Connect,CnC);
		}
	}

	cout <<endl<< "The number of connected components: "<< CnC<<endl;			// print connect lists

	for (int i = 1; i <=CnC ; ++i)
	{
		temp=Connect[i]->next;
		cout << "\tConnected components " << i <<" : ";
		while(temp!=NULL){

			cout << temp->data<<" ";
			temp=temp->next;
		}
		cout << endl;		
	}

	cout <<endl<< "The number of cycles: "<< CyC<<endl;				// print cycles list with its parent

	for (int i = 1; i <= CyC; ++i)
	{
		cout << "\tCycle " << i <<" : ";
		print_path(Head, cycles,i);
		cout << endl;
	}

	return 0;
}