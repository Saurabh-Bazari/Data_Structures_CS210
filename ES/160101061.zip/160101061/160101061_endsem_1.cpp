#include <bits/stdc++.h>
using namespace std;

struct node
{
	int key;
	int priority;
	node *left;
	node *right;
};

node *create(int k){  // create

	node *temp=new node;

	temp->key=k;
	temp->priority=rand()%100000;
	temp->left=NULL;
	temp->right=NULL;

	return temp;
}

void inorder(node *root){  

	if (root==NULL)
	{
		return;
	}

	inorder(root->left);
	cout << root->key <<" ";
	inorder(root->right);

	return;
}
void preorder1(node *root){

	if (root==NULL)
	{
		return;
	}

	cout << root->key <<" " << root->priority<<endl;;
	preorder1(root->left);
	preorder1(root->right);

	return;
}

void rotate_left(node * &root){  //rotate left

	if (root->right==NULL)
	{
		return;
	}

	node *rr=root->right;

	node *rrl=rr->left;

	root->right=rrl;

	rr->left=root;

	root=rr;

	return;
}

void rotate_right(node * &root){  // rotate right

	if (root->left==NULL)
	{
		return;
	}

	node *rl=root->left;

	node *rlr=rl->right;

	root->left=rlr;

	rl->right=root;

	root=rl;

	return;
}

void insert(node * &root,int k){   //insert

	if (root==NULL)
	{
		root=create(k);
		return;
	}

	if (root->key > k)
	{
		if (root->left ==NULL)
			root->left=create(k);

		else
			insert(root->left,k);
	}
	else if (root->key < k)
	{
		if (root->right ==NULL)
			root->right=create(k);

		else
			insert(root->right,k);
	}

	if (root->left!=NULL && root->priority > root->left->priority )
		rotate_right(root);

	if (root->right!=NULL && root->priority > root->right->priority )
		rotate_left(root);
	
	return;
}

node *search(node *root,int k){  //search

	if (root==NULL || root->key==k)
	{
		return root;
	}

	if (root->key > k)
	{
		return search(root->left,k);
	}
	else
	{
		return search(root->right,k);
	}
}

node *parent(node *root,node *temp){    // find parent

	if (root==NULL || root->left==temp || root->right ==temp)
	{
		return root;
	}

	if ( root->key > temp->key)
	{
		return parent(root->left,temp);
	}
	else{

		return parent(root->right,temp);
	}
}

void deleted(node * &root,int k){    // delete

	node *temp=search(root,k);

	if (temp==NULL)
	{
		cout << k <<"is not found" << endl;
		return ;
	}

	if (temp->left==NULL && temp->right==NULL)
	{
		if (root==temp)
			root=NULL;
		else
		{
			node *p=parent(root,temp);

			if (p->left==temp)
			{
				p->left=NULL;
			}
			else
				p->right=NULL;
		}
		
		free(temp);
		return;
	}

	if (temp->left==NULL)
	{
		rotate_left(temp);

		temp->left=NULL;

		return;
	}


	if (temp->right==NULL)
	{
		rotate_right(temp);

		temp->right=NULL;

		return;
	}

	rotate_right(temp);
	deleted(root,k);

	return;
}

bool checkMinHeap(int A[], int i, int n){

	if (2*i + 2 > n)
		return true;
	
	bool left = (A[i] <= A[2*i + 1]) && checkMinHeap(A, 2*i + 1, n);
	
	bool right = ((2*i + 1 == n) ||(A[i] <= A[2*i + 2] && checkMinHeap(A, 2*i + 2, n)));
	
	return left && right;
}



void preorder(node *root,int A[],int &count){

	if (root==NULL)
	{
		return;
	}
	
	A[count++]=root->priority;
	preorder(root->left,A,count);
	preorder(root->right,A,count);

	return;
}

int main()
{
	string s;
	int k,count;
	int A[10000];

	node *root=NULL;

	while(1){

		count =0;

		cin >> s;

		if (s=="-1")
			break;

		cin >> k;

		if (s=="INSERT" || s=="i")
		{
			insert(root,k);
		}
		if (s=="DELETE" || s=="d")
		{
			deleted(root,k);
		}

		inorder(root);
		cout << endl;
			preorder(root,A,count);

		if(checkMinHeap( A,0,count )){
			cout << "1"<<endl;

		}
		else{
			cout << "0" <<endl;
		}

	}

	


	return 0;
}