#include <bits/stdc++.h>
using namespace std;

struct node		//struct node
{
	int occur;
	int key;
	node *left;
	node *right;
	node *parent;
};

node *create(int k,int o){

	node *temp=new node;

	temp->key=k;
	temp->occur=o;
	temp->left=NULL;
	temp->right=NULL;
	temp->parent=NULL;

	return temp;
}

node *minn(node *n){				// find min

	while(n->left!=NULL)
		n=n->left;
	
	return n;
}

node *successor(node *root,node *h){   		 // find Successor and predecessor 

	if (h->right!=NULL)
		return minn(h->right);
	
	else{

		node *y=h->parent;

		while(y!=NULL && h==y->right){

			h=y;
			y=y->parent;
		}

		return y;
	}
}

node *maxx(node *n){

	while(n->right!=NULL)
		n=n->right;
	
	return n;
}

node *predecessor(node *root,node *h){

	if (h->left!=NULL)
		return maxx(h->left);
	
	else{

		node *y=h->parent;

		while(y!=NULL && h==y->left){

			h=y;
			y=y->parent;
		}

		return y;
	}
}

void insert(node * &root, int k,int o){  		// insert node of k,o in root node tree

	node * temp= create(k,o);

	if (root==NULL)
	{
		root=temp;
		return;
	}

	node *t=root,*p;

	while(t!=NULL){

		p=t;

		if (t->occur < o)
			t=t->left;

		else if (t->occur > o)
			t=t->right;

		else
		{
			if (t->key < k)
			{
				if (t->right==NULL)
				{				
					t->right=temp;
					temp->parent=t;
					return;
				}

				while( t!=NULL && t->key < k && t->occur == o ){

					p=t;
					t=successor(root,t);
				}

				if (p->right==NULL || t==NULL)
				{
					p->right=temp;
					temp->parent=p;
					return;
				}

				t->left=temp;
				temp->parent=t;
			}

			else
			{
				if (t->left==NULL)
				{				
					t->left=temp;
					temp->parent=t;
					return;
				}

				while( t!=NULL && t->key > k && t->occur == o){

					p=t;
					t=predecessor(root,t);
				}

				if (p->left==NULL || t==NULL)
				{
					p->left=temp;
					temp->parent=p;
					return;
				}

				t->right=temp;
				temp->parent=p;
			}
			
			return;
		}
	}
	temp->parent = p;

	if (p->occur < o){
		p->left=temp;
	}
	else{
		p->right=temp;
	}
	return;
}

void inorder(node *root){  					// print data

	if (root==NULL)
		return;

	inorder(root->left);

	for (int i = 0; i < root->occur ; ++i)
		cout << root->key << " ";

	inorder(root->right);

	return;
}

void tranvrese(node *root1,node *&root){			// tranverse tree as inorder of root1 node and insert node root1 in root node tree

	if (root1==NULL)
		return;

	tranvrese(root1->left,root);
	insert(root,root1->key,root1->occur);
	tranvrese(root1->right,root);

	return;
}

void insert1(node * &root1,int n){				// insert node for calculate freq.

	if (root1==NULL)
	{
		node *temp=create(n,1);
		root1=temp;
		return;
	}

	if (root1->key==n)
	{
		(root1->occur)++;
		return;
	}

	if (root1->key > n)
		insert1(root1->left,n);

	else
		insert1(root1->right,n);
	
	return ;
}

int main()
{
	int N,n=0;
	cin >> N;

	node *root=NULL;
	node *root1=NULL;
	
	for (int i = 0; i < N; ++i){
		
		cin >> n;
		insert1(root1,n);
	}

	tranvrese(root1,root);

	inorder(root);

	cout << endl;

	return 0;
}