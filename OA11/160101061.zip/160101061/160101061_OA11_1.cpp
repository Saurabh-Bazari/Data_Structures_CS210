#include <iostream>
using namespace std;

struct node    				//struct node for tree
{
	int key;
	node *left;
	node *right;
	node *parent;
};

struct node1				// struct node for linked list
{
	int key;
	node *tree;
	node1 *next;
};

node *create(int k){			//create

	node *temp=new node;

	temp->key=k;
	temp->left=NULL;
	temp->right=NULL;
	temp->parent=NULL;

	return temp;
}

node1 *create1(int k,node *temp1){			//create

	node1 *temp=new node1;

	temp->key=k;
	temp->tree=temp1;
	temp->next=NULL;

	return temp;
}

void insert(node * &root, int k){		// insert k in root node tree

	node * temp= create(k);

	if (root==NULL)
	{
		root=temp;
		return;
	}

	node *t=root,*p;

	while(t!=NULL){

		p=t;

		if (t->key > k)
			t=t->left;

		else
			t=t->right;
	}

	if (p->key > k){

		p->left=temp;
		temp->parent=p;
	}
	else{
		p->right=temp;
		temp->parent=p;
	}
	return;
}

node1 *cpy(node1 *head){		 // create copied file of head node1 linked list



	node1 *t=head;
	node1 *headcopied=NULL;
	node1 *pervcpy, *temp1;

	while(t!=NULL){

		temp1=create1(t->key,t->tree);

		if (headcopied==NULL)
		{
			headcopied=temp1;
			pervcpy=headcopied;
		}
		else{
			pervcpy->next=temp1;
			pervcpy=temp1;
		}

		t=t->next;
	}

	return headcopied;
}

void Delete(int  d,node1 * &head){ 		// delete node1 if value d from node1 head linked list

	if (head->key==d)
	{
		head=head->next;
		return;
	}

	node1 * temp=head,* perv;

	while(temp->key!=d){

		perv=temp;
		temp=temp->next;
	}

	perv->next=temp->next;

	return;
}

void call(node1 * &head,node1 *d1,node *root,int N,int **data,int index,int &count)		// 
{

	if (head==NULL)			// if head is null
	{
		return;
	}

	node1* d=head;

	while(d->key!=d1->key) 			// find copy of d1 in d
		d=d->next;

	data[count][index]=d->key;		// assign value

	if (index==N-1)					// if index is N-1 copy full array in next array 
	{
		data[count+1]=new int [N];

		for (int i = 0; i < N; ++i)
		{
			data[count+1][i]=data[count][i];
		}

		count++;
	}


	node *temp=d->tree;
	node1 *nexttt=NULL;

	if (temp->right!=NULL)								// if right exist
	{
		nexttt=create1(temp->right->key,temp->right);

		nexttt->next=d->next;
		d->next=nexttt;
	}

	if (temp->left!=NULL)								// if left exist
	{
		nexttt=create1(temp->left->key,temp->left);

		nexttt->next=d->next;
		d->next=nexttt;
	}

	int k=d->key;

	Delete(k,head);				// delete k

	node1 *te=head;

	node1 * headcopied;		// headcopied copy file of head 

	while(te!=NULL){

		headcopied=cpy(head);

		call(headcopied,te,root,N,data,index+1,count); 		// headcopied file in call function with index+1

		te=te->next;
	}

	return;
}


int main()
{
	int N;
	cin >> N;

	int A[N];
	node *root=NULL;
	
	for (int i = 0; i < N; ++i){			// inpur and make tree
		cin >> A[i];
		insert(root,A[i]);
	}

	node1 *head=NULL;

	head=create1(root->key,root);

	int **data;
	int count=0;

	data=new int *[9999999];

	data[count]=new int [N];

	call(head,head,root,N,data,0,count);  // call call function

	cout << count <<endl;				// print data

	for (int i = 0; i < count; ++i)
	{
		for (int j = 0; j < N; ++j)
		{
			cout << data[i][j] <<" "; 
		}
		cout << endl;
	}

	return 0;
}

/*

5
3 1 2 4 5

*/