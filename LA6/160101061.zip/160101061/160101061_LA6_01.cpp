#include <bits/stdc++.h>
using namespace std;
int h=INT_MAX;

void insert1(long long int hash1[],int N,int m,float &c1){

	int i=0,j;

	do{
	j=((N+i)%m);

	if (hash1[j]==-1 || hash1[j]==h)
	{
		hash1[j]=N;
		cout <<  N <<" INSERTED AT INDEX " <<j <<" IN LINEAR PROBING" << endl;
		c1=c1+i;
		return;
	}
	else
		i++;

	}while(i<m);

		cout << "OVERFLOW!"<<endl;

	return;
}

void search1(long long int hash1[],int N,int m){

	int i=0,j;

	do{
	j=((N+i)%m);

	if (hash1[j]==N)
	{
		
		cout <<  N <<" FOUND AT INDEX " <<j <<" IN LINEAR PROBING" << endl;

		return;
	}
	else
		i++;

	}while(i<m && hash1[j]!=-1);

		cout << "NOT FOUND!"<<endl;

	return;
}

void delete1(long long int hash1[],int N,int m){

	int i=0,j;

	do{
	j=((N+i)%m);

	if (hash1[j]==N)
	{
		hash1[j]=h;
		
		cout <<  N <<" DELETE FROM INDEX " <<j <<" IN LINEAR PROBING" << endl;

		return;
	}
	else
		i++;

	}while(i<m && hash1[j]!=-1);

		cout << "NOT FOUND!"<<endl;

	return;
}

void insert2(long long int hash1[],int N,int m,float &c2){

	int i=0,j;

	do{
	j= ((N%m) + i +(3*i*i))%m ;

	if (hash1[j]==-1 || hash1[j]==h)
	{
		hash1[j]=N;
		cout <<  N <<" INSERTED AT INDEX " <<j <<" IN QUADRATIC PROBING" << endl;
		
		c2=c2+i;

		return;
	}
	else
		i++;

	}while(i<m);

		cout << "OVERFLOW!"<<endl;

	return;
}

void search2(long long int hash1[],int N,int m){

	int i=0,j;

	do{
	j= ((N%m) + i +(3*i*i))%m ;

	if (hash1[j]==N)
	{
		
		cout <<  N <<" FOUND AT INDEX " <<j <<" IN QUADRATIC PROBING" << endl;

		return;
	}
	else
		i++;

	}while(i<m && hash1[j]!=-1);

		cout << "NOT FOUND!"<<endl;

	return;
}

void delete2(long long int hash1[],int N,int m){

	int i=0,j;

	do{
	j= ((N%m) + i +(3*i*i))%m ;

	if (hash1[j]==N)
	{
		hash1[j]=h;
		
		cout <<  N <<" DELETE FROM INDEX " <<j <<" IN QUADRATIC PROBING" << endl;

		return;
	}
	else
		i++;

	}while(i<m && hash1[j]!=-1);

		cout << "NOT FOUND!"<<endl;

	return;
}

void insert3(long long int hash1[],int N,int m,float &c3){

	int i=0,j;

	if (m==1)
	{
		cout << " NOT POSSIBLE" << endl;
		return;
	}

	do{
	j= ((N%m) + (i*(1+(N%(m-1)))))%m ;

	if (hash1[j]==-1 || hash1[j]==h)
	{
		hash1[j]=N;
		cout <<  N <<" INSERTED AT INDEX " <<j <<" IN DOUBLE HASING" <<endl;

		c3=c3+i;

		return;
	}
	else
		i++;

	}while(i<m);

		cout << "OVERFLOW!"<<endl;

	return;
}

void search3(long long int hash1[],int N,int m){

	int i=0,j;

	do{
	j= ((N%m) + (i*(1+(N%(m-1)))))%m ;

	if (hash1[j]==N)
	{
		
		cout <<  N <<" FOUND AT INDEX " <<j <<" IN DOUBLE HASING" << endl;

		return;
	}
	else
		i++;

	}while(i<m && hash1[j]!=-1);

		cout << "NOT FOUND!"<<endl;

	return;
}

void delete3(long long int hash1[],int N,int m){

	int i=0,j;

	do{
	j= ((N%m) + (i*(1+(N%(m-1)))))%m ;

	if (hash1[j]==N)
	{
		hash1[j]=h;
		
		cout <<  N <<" DELETE FROM INDEX " <<j <<" IN DOUBLE HASING" << endl;

		return;
	}
	else
		i++;

	}while(i<m && hash1[j]!=-1);

		cout << "NOT FOUND!"<<endl;

	return;
}

int main(){

	int n,m,N;
	cin >> n >> m;

	char s[10];

	long long int hash1[m],hash2[m],hash3[m];

	for (int i = 0; i < m; ++i)
	{
		hash1[i]=-1;
		hash2[i]=-1;
		hash3[i]=-1;
	}

	float c1=0,c2=0,c3=0;
	int int_call=0;

	for (int i = 0; i < n; ++i)
	{
		cin >> s;
		cin >> N;

		if (strcmp(s,"INSERT")==0)
		{
			int_call++;
			insert1(hash1,N,m,c1);
			insert2(hash2,N,m,c2);
			insert3(hash3,N,m,c3);
		}
		else if (strcmp(s,"SEARCH")==0)
		{
			search1(hash1,N,m);
			search2(hash2,N,m);
			search3(hash3,N,m);
		}
		else if (strcmp(s,"DELETE")==0)
		{
			delete1(hash1,N,m);
			delete2(hash2,N,m);
			delete3(hash3,N,m);
		}
	}

	cout << "TOTAL NUMBER OF COLLISIONS IN LINEAR PROBING " << c1 <<endl;
	cout << "TOTAL NUMBER OF COLLISIONS IN QUADRATIC PROBING " << c2 <<endl;
	cout << "TOTAL NUMBER OF COLLISIONS IN DYNAMIC PROBING " << c3 <<endl;

	float f1,f2,f3;

	f1=c1/int_call;
	f2=c2/int_call;
	f3=c3/int_call;

	cout << "AVERAGE NUMBER OF REHASING REQUIRED IS "<< f1 <<" IN LINEAR PROBING"  <<endl;
	cout << "AVERAGE NUMBER OF REHASING REQUIRED IS " << f2 <<" IN QUADRATIC PROBING" <<endl;
	cout << "AVERAGE NUMBER OF REHASING REQUIRED IS " << f3 <<" IN DOUBLE HASHING" <<endl;


	return 0;
}