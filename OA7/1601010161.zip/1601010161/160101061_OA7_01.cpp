#include <bits/stdc++.h>
using namespace std;

void PrinT(int H[],int n){			// print HEAP

	for (int i = 0; i < n; ++i)
	{
		cout << H[i]<<" ";
	}
	printf("\n\n");

}

void min_heapify(int H[],int n,int i){		// min Heapify for 1D array in trinary heap

	int large=i;
	int l=(3*i)+1;
	int m=(3*i)+2;
	int r=(3*i)+3;

	if (l<n && H[large] > H[l])
		large=l;

	if (m<n && H[large] > H[m])
		large=m;

	if (r<n && H[large] > H[r])
		large=r;

	if (large!=i)
	{
		swap(H[i],H[large]);
		min_heapify(H,n,large);
	}

	return;
}

void min_heapify2(int H[][2],int n,int i){			// min Heapify for 2D array in trinary heap

	int large=i;
	int l=(3*i)+1;
	int m=(3*i)+2;
	int r=(3*i)+3;

	if (l<n && H[large][0] > H[l][0])
		large=l;

	if (m<n && H[large][0] > H[m][0])
		large=m;

	if (r<n && H[large][0] > H[r][0])
		large=r;

	if (large!=i)
	{
		swap(H[i],H[large]);
		min_heapify2(H,n,large);
	}

	return;
}

void InserT(int H[],int &n,int k){							// Insert element in 1D array

	H[n]=k;
	n++;

	int s=n-1;
	int p=(s-1)/3;

	while(s>0 && H[p] > H[s]){
		swap(H[s],H[p]);
		s=p;
		p=(p-1)/3;
	}

	return;
}

void InserT2(int H[][2],int &n,int k,int index){			// insert element in 2D array and also store index of that element

	H[n][0]=k;
	H[n][1]=index;
	n++;

	int s=n-1;
	int p=(s-1)/3;

	while(s>0 && H[p][0] > H[s][0]){
		swap(H[s],H[p]);
		s=p;
		p=(p-1)/3;
	}

	return;
}

// First insert the 0th element of main heap and loop run for k times
// in loop first print the min of new 2D array and store index and if their left,middle and right are exist then insert in 2D array
// And in last delete min and min_heapify

void ksmallest(int H[],int &n,int k){

	int TrY[n][2]={0};
	int tn=0,k1,l,r,m;

	InserT2(TrY,tn,H[0],0);

	for (int i = 0; i < k && i < n; ++i)
	{
		cout << TrY[0][0] << " ";

		k1=TrY[0][1];

		l=(3*k1)+1;
		m=(3*k1)+2;
		r=(3*k1)+3;

		if (l<n)
			InserT2(TrY,tn,H[l],l);

		if (m<n)
			InserT2(TrY,tn,H[m],m);

		if (r<n)
			InserT2(TrY,tn,H[r],r);

		swap(TrY[0],TrY[--tn]);
		min_heapify2(TrY,tn,0);
	}

	printf("\n\n");

	PrinT(H,n);

	return;
}

// Same as above function but it stop on if all elements are less than k or till min element is greatre then k

void printsmall(int H[],int &n,int k){

	int TrY[n][2]={0};
	int tn=0,k1,l,r,m;

	InserT2(TrY,tn,H[0],0);

	for (int i = 0; i < n; ++i)
	{
		if (TrY[0][0] > k)
			break;
		


		cout << TrY[0][0] << " ";

		k1=TrY[0][1];

		l=(3*k1)+1;
		m=(3*k1)+2;
		r=(3*k1)+3;

		if (l<n)
			InserT2(TrY,tn,H[l],l);

		if (m<n)
			InserT2(TrY,tn,H[m],m);

		if (r<n)
			InserT2(TrY,tn,H[r],r);

		swap(TrY[0],TrY[--tn]);
		min_heapify2(TrY,tn,0);
	}

	printf("\n\n");

	PrinT(H,n);

	return;
}

// built min heap of main array

void buildheap(int H[],int n,int k){

	for (int i = k; i >= 0 ; --i)
		min_heapify(H,n,i);

	return;
}

int main(){

	int n,k,k1,k2;
	cin >> n;
	
	int H[n];

	for (int i = 0; i < n; ++i)
		cin >> H[i];

	cin >> k1>>k2;
	k=(n-2)/3;

	buildheap(H,n,k);			// built min heap

	printf("\n");
	PrinT(H,n);					// print main array
	ksmallest(H,n,k1);			// print k1 smallest element
	printsmall(H,n,k2);			// print elements till element greater than k2 

	return 0;
}