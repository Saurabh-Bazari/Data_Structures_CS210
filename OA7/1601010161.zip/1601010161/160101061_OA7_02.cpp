#include <bits/stdc++.h>
using namespace std;

struct node
{
	int key;
	int degree;
	node *child,*parent,*left,*right;
	bool mark;
};

node *create(int d){							// create node

	node *temp=new node;
	temp->key=d;
	temp->degree=0;
	temp->child=temp->left=temp->right=temp->parent=NULL;

	return temp;
}

int FH_min(node *head){						// return min key

	if (head==NULL){
		cout << "Heap is Empty" << endl;
		return -1;
	}

	return head->key;
}

void makeheap(node **head){					// make heap just as head=null

	(*head)=NULL;
	return;
}

void concat(node *temp,node **head){		// connect 2 heap

	if ((*head)==NULL)
	{
		(*head)=temp;
		return;
	}

	node *head_next=(*head)->right;
	node *temp_next=temp->right;

	(*head)->right=temp_next;
	temp_next->left=(*head);
	temp->right=head_next;
	head_next->left=temp;
	
	return;
}

void Union(node **head,node *h1){			// Union of 2 heap first concat it and find min

	if (h1==NULL)
		return;
	
	concat(h1,head);

	if ((*head)->key > h1->key)
		(*head)=h1;

	return;
}

void InserT(node **head,int k){				// insert a node in heap

	node *temp;
	temp=create(k);
	temp->left=temp->right=temp;

	Union(head,temp);

	return;
}

void print(node *head,int depth){					// print a heap with its depth

	for (int i = 0; i <= depth; ++i)
		cout << "\t";

	cout << head->key  << "\t" ;

	return;
}

void show_F_Heap(node *head,int depth){				// show a full heap

	if (head==NULL)						
	{
		printf("Empty heap\n");
		return;
	}

	print(head,depth);

	if (head->child!=NULL)
		show_F_Heap(head->child,depth+1);

	printf("\n");

	node *t=head->right;

	while(t!=head)
	{
		print(t,depth);

		if (t->child!=NULL)
			show_F_Heap(t->child,depth+1);

		t=t->right;
		printf("\n");
	}

	return;
}

void link(node *head,node *x,node *y){			// link y as child of x

	(y->left)->right=y->right;
	(y->right)->left=y->left;
	y->right=y->left=y;

	y->parent=x;

	if (x->child ==NULL)
	{
		x->child=y;
		y->right=y->left=y;
	}
	else{
		x=x->child;

		node *x_next=x->right;
		node *y_next=y->right;

		x->right=y_next;
		y_next->left=x;
		y->right=x_next;
		x_next->left=y;
	}

	return;
}

int num(node *head){					// find the max degree in consolidate 

	node *t=head;

	if (t==NULL)
		return 0;

	if (t==t->right)
		return (t->degree)+1;

	int i=1,dmax=t->degree;

	while(t->right!=head){
		i++;
		t=t->right;

		if (dmax < t->degree)
			dmax=t->degree;

	}

	i=log2(i);
	i=max(i,dmax);

	return i+1;

}

node *Consolidate(node *head){			// consolidate the heap

	int n=num(head);

	node *A[n+1];

	for (int i = 0; i < n+1; ++i)
		A[i]=NULL;

	node *x,*w,*y;
	w=head;
	int flag=0,d;

	while(flag==0 || w!=head){				// run (number of nodes in root line )times

		x=w;
		d=w->degree;

		while(A[d]!=NULL){			// till A[d] is null

			y=A[d];

			if (x->key > y->key)
				swap(x,y);

			if (y==head)			
				head=head->right;

			if (y==w)
				w=w->left;
 			
			link(head,x,y);

			A[d]=NULL;

			(x->degree)++;
			d++;
		}

		A[d]=x;
		w=w->right;
		flag=1;

	}

	return head;
}

void find_min(node **head){			// find min in heap after extract min

	node *t=(*head),*t1=NULL;
	int d=(*head)->key;

	while(t->right!=(*head)){

		if (d>t->right->key){
			d=t->right->key;
			t1=t->right;		
		}

		t=t->right;
	}

	if (t1==NULL)
		return;

	(*head)=t1;
	return;
}

int Extract_min(node **head){ 			// extract min

	if ((*head)==NULL)				// if heap is null then return -1
		return -1;

	int d=(*head)->key;

	node *t=(*head)->right,*t1=NULL;

	if ((*head)->right==(*head))			// if only one node is present
	{
		if ((*head)->child==NULL)
			(*head)=NULL;
		
		else{
			t1=(*head);
			(*head)=(*head)->child;
			(*head)->parent=NULL;
			free(t1);
			(*head)=Consolidate(*head);
			find_min(head);
		}
		return d;
	}

	(*head)->left->right=(*head)->right;		// remove min node
	(*head)->right->left=(*head)->left;

	t1=(*head)->child;

	(*head)=t;

	if (t1!=NULL)
	 	t1->parent=NULL;

	Union(head,t1);
	(*head)=Consolidate(*head);
	find_min(head);

	return d;
}

int main(){

	char c;
	int d,flag=0,e=0;
	node *head=NULL,*h1=NULL;

	while(1){			// if heap is empty and futher extract min use then stop it

		cin >> c;

		if (c=='#')					// if input is # ingore till enter
			cin.ignore(10e9,'\n');

		else if (c=='c')			// make heap
			makeheap(&head);
		
		else if (c=='u')		// call union
			Union(&head,h1);
		
		else if (c=='i')		// call insert
		{
			cin >> d;
			InserT(&head,d);
		}

		else if (c=='e'){			// extract min
			e=Extract_min(&head);

			if (e==-1){
				cout << "Empty Heap" << endl;
				return 0;
			}

			if (flag==0)
				cout << "Minimum extracted: " << e << endl;
		}

		else if (c=='+')		//flag on
			flag=0;
		
		else if (c=='-')  		// flag off
			flag=1;	

		else if (c=='S'){		// print heap
			cout << endl;
			show_F_Heap(head,0);
			cout << endl;

		}		
	}

	return 0;
}