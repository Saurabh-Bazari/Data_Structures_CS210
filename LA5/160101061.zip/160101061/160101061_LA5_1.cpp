#include <bits/stdc++.h>
using namespace std;

// white=0 grey=1 black =-1

struct node
{
	int key;
	int colour;
	int good_bad;
	node *next;
};

node *create(int k){

	node *temp=new node;
	temp->key=k;
	temp->colour=0;
	temp->good_bad=0;
	return temp;
}

void add(node *list[],int n1,int n2){

	node *temp=create(n2);

	temp->next=list[n1]->next;
	list[n1]->next=temp;

	return;
}

bool search(node *g ,int k){

	node *t=g->next;

	while(t!=NULL){

		if (t->key==k)
			return true;

		t=t->next;
	}

	return false;

}

void add1(node *list,int n2){

	if (search(list,n2)==1)
		return;

	node *temp=create(n2);

	temp->next=list->next;
	list->next=temp;

	return;
}

int fc(node *g,node *b){

	node *t1=g->next;
	node *t2=b->next;

	while(t1!=NULL){

		t2=b->next;

		while(t2!=NULL){

			if (t1->key==t2->key)
				return 0;
			
			t2=t2->next;
		}

		t1=t1->next;
	}

	return 1;


}

void print(node *g,node *b){

	node *t=NULL;

	printf("\nGood Guys: \n");

	t=g->next;

	while(t!=NULL){
		cout << t->key << " ";
		t=t->next;
	}

	printf("\nBad Guys: \n");

	t=b->next;

	while(t!=NULL){
		cout << t->key << " ";
		t=t->next;
	}
	printf("\n");
}

bool check(node *list[],int n){

	node *t,*g=NULL,*b=NULL;
	int curr=0;

	g=create(0);
	b=create(0);

	add1(b,list[1]->key);
	list[1]->good_bad=-1;

	t=list[1]->next;

	while(t!=NULL)
	{
		add1(g,t->key);
		list[t->key]->good_bad=1;
		t=t->next;
	}


	for (int i = 2; i <= n; ++i)
	{
		t=list[i]->next;

		if (list[i]->good_bad==1)
		{

			while(t!=NULL){
				add1(b,t->key);
				list[t->key]->good_bad=-1;
				t=t->next;
			}

		}

		if (list[i]->good_bad==-1)
		{

			while(t!=NULL){
				add1(g,t->key);
				list[t->key]->good_bad=1;
				t=t->next;
			}

		}
	}	

		if (fc(g,b)==0)
		{
			return false;
		}

		print(g,b);
	

	return true;
}

int main(){

	int n,r,n1,n2;

	cin >> n >> r;

	node *list[n+1];

	for (int i = 1; i <= n; ++i)
		list[i]=create(i);

	for (int i = 0; i < r; ++i)
	{
		cin >> n1 >> n2;

		add(list,n1,n2);
		add(list,n2,n1);
	}

	node *temp;

	if (check(list,n)==0)
		cout << " Not Possible" << endl;
	

	return 0;
}