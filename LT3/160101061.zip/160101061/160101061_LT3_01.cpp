#include <bits/stdc++.h>
using namespace std;

struct node{
	int data;
	int colour;
	node *next;
};

node *create(int k){

	node *t;
	t=new node;
	t->data=k;
	t->next=NULL;
	t->colour=0;

	return t;
}

void add(node *a,int k){

	node *temp=create(k);
	node *t=a;

	if (a->next==NULL)
	{
		a->next=temp;
		temp->next=NULL;
		return;
	}

	while(t->next!=NULL)
		t=t->next;

	t->next=temp;
	temp->next=NULL;
	return;
}

void DFS(node *Head[],int k,int d[],int &time,int stack[],int &top,int te[][2],int be[][2],int fe[][2],int ce[][2],int &tec,int &bec,int &fec,int &cec){

	node *temp=Head[k]->next,*t=Head[k];
	Head[k]->colour=1;

	if (d[k]==0)
	{
		d[k]=++time;
	}


	while(temp!=NULL){

		if (Head[temp->data]->colour==0)
		{
			stack[++top]=temp->data;
			Head[temp->data]->colour=1;

			while(t->next!=temp)
				t=t->next;

			t->next=t->next->next;



			te[tec][0]=k;
			te[tec][1]=temp->data;
			tec++;

			return;
		}
		else if(Head[temp->data]->colour==1){
			
			be[bec][0]=k;
			be[bec][1]=temp->data;
			bec++;
		}
		else{

			if (d[k] < d[temp->data])
			{
				fe[fec][0]=k;
				fe[fec][1]=temp->data;
				fec++;
			}
			else{

				ce[cec][0]=k;
				ce[cec][1]=temp->data;
				cec++;
			}
		}

		while(t->next!=temp)
				t=t->next;

			t->next=t->next->next;

		temp=temp->next;
	}

	top--;
	Head[k]->colour=2;

	return;
}


int main()
{
	int N,E;
	cin >> N >> E;

	char a,b;

	node *Head[26];

	for (int i = 0; i < 26; ++i)
	{
		Head[i]=create(i);		
	}

	int stack[N],top=-1,a1,b1;

	for (int i = 0; i < E; ++i)
	{
		cin >> a >> b;
		a1=a-'a';
		b1=b-'a';

		add(Head[a1],b1);		
	}

	node *temp;

	// for (int i = 0; i < 26; ++i)
	// {
	// 	temp=Head[i];

	// 	while(temp!=NULL){
	// 		a='a'+temp->data;
	// 		cout << a<< " ";
	// 		temp=temp->next;
	// 	}
	// 	printf("\n");
	// }

	int te[N][2],be[N][2],fe[N][2],ce[N][2],tec=0,bec=0,fec=0,cec=0;
	int d[26]={0},time=0,p;

	for (int i = 0; i < 26; ++i)
	{
		if (Head[i]->colour==0)
		{
			stack[++top]=Head[i]->data;
			
			DFS(Head,i,d,time,stack,top,te,be,fe,ce,tec,bec,fec,cec);

			while(top!=-1){

				p=stack[top];

				DFS(Head,p,d,time,stack,top,te,be,fe,ce,tec,bec,fec,cec);
			}
		}
	}

	cout <<endl<< "For part 1:" << endl << "\t\t";
	for (int i = 0; i < tec; ++i)
	{
		a='a' + te[i][0] ;
		b='a' + te[i][1] ;
		cout << " ("<< a << "," << b<< ") " ;
	}

	cout << "\n\nFor part 2:" << endl;

	cout <<"Tree edges: \t" ;

	for (int i = 0; i < tec; ++i)
	{
		a='a' + te[i][0] ;
		b='a' + te[i][1] ;
		cout << " ("<< a << "," << b<< ") " ;
	}

	cout <<endl<< "Back edges: \t";

	for (int i = 0; i < bec; ++i)
	{
		a='a' + be[i][0] ;
		b='a' + be[i][1] ;
		cout << " ("<< a << "," << b<< ") " ;
	}

	cout <<endl<<"Forward edges: \t";


	for (int i = 0; i < fec; ++i)
	{
		a='a' + fe[i][0] ;
		b='a' + fe[i][1] ;
		cout << " ("<< a << "," << b<< ") " ;
	}

	cout << endl<<"Cross edges: \t";

	for (int i = 0; i < cec; ++i)
	{
		a='a' + ce[i][0] ;
		b='a' + ce[i][1] ;
		cout << " ("<< a << "," << b<< ") " ;
	}
	cout << endl << endl;

	
	
	return 0;
}