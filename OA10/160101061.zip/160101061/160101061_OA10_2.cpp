
#include <bits/stdc++.h>
using namespace std;

int rolling_hash(string s,int i1,int i2)  		// find hash value of string s from i1 to 12
{
	int h=1008001;

    int j = 0,j1;
    for (int i = i1-1; i < i2; i++)
    {
        j1=s[i]-'a';
        j = (j*27 + j1+1)%h;
    }
    return j;
}

int string_lenght(string s){		// string length

	int len=0;

	for(int i = 0; s[i] != '\0'; ++i)
        len=i+1;

    return len;
}


void rolling_hash1(string big,string small)			// remove all possible substring from big string
{
	int h=1008001;

    int len_big=string_lenght(big);
    int len_small=string_lenght(small);

    int small_general=rolling_hash(small,1,len_small);
    int big_general=0;
    int max_power=1;
    
    int count=1,n1,n2,co=0;

    for (int i = 1; i < len_small; ++i) 			// max power of 27 reached in small string
		max_power=(max_power*27)%h;

    while(count!=0){							// till no change occur
        count=0;
        len_big=string_lenght(big);
        big_general=0;
       
        for (int i =1; i <=len_big; ++i)			
        {
        	n2=big[i-1]-'a';								// bulid hash value of sub string from big string of lenght len_small  
        	big_general=(big_general*27 + n2+1)%h;
        	
        	if (i >= len_small )
        	{												// if lenght exceed len_small delete first char from hash value 

        		if (big_general==small_general)				// if hash value matched
        		{
                    co=0;
                    for (int j = 0 ; j < len_small ; ++j)
                        if (big[j+i-len_small]==small[j])
                            co++; 

                    if (co==len_small)
                    {
                        big.erase (i-len_small,len_small); 
                        len_big=len_big-len_small;
                        i=i-len_small;
                        count++;    
                        break;            
                    }
        		}

	            n1=big[i-len_small]-'a';								// delete first char
	            big_general=(big_general-((max_power*(n1+1))%h))%h;
        	}
        }
    }

    cout << big << endl;

    return ;
}

void call_function(){

    string big,small;

    cin >> big;
    cin >> small;

    rolling_hash1(big,small);

    return;
}

int main()
{
    int N;
    cin >> N;

    for (int i = 0; i < N; ++i)
    {
        call_function();
    }

    return 0;

}

/*

1
ababccdabce
abc


*/