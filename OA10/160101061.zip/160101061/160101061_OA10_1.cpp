#include <iostream>
#include <climits>

using namespace std;


int rolling_hash(string s,int i1,int i2)		// find hash value from inder i1 to i2 in string s
{
	int h=1008001;

    int j = 0,j1;
    for (int i = i1-1; i < i2; i++)
    {
    	j1=s[i]-'a';
        j = (j*26 + j1)%h;
    }
    return j;
}

int main()
{
    int N,n1,n2,i1,i2,i3,i4,count=0;
    string s;

    cin >> s;
    cin >> N;

    for (int i = 0; i < N; ++i)
    {
    	count=0;
        cin >> i1 >> i2 >> i3 >> i4;

        n1=rolling_hash(s,i1,i2);
        n2=rolling_hash(s,i3,i4); 

        if (n1==n2){									// if hash value of substring is same then compare string

        	for (int j = -1; j < i2-i1 ; ++j)
        		if (s[j+i1]==s[j+i3])
        			count++;        		

        	if (count==(i2-i1+1))
				cout << "YES" << endl;
			else
            	cout << "NO" << endl;
        }
        else
            cout << "NO" << endl;
    }
    return 0;
}

/*

abcababcbb
3
1 2 4 5
1 3 6 8
1 2 2 3


*/